
console.log("Cassino pqd.bet ativo!");
